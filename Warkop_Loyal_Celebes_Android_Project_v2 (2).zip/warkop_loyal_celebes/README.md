# Warkop Loyal Celebes — Android starter project

## Status build
Proyek kode sumber tersedia, tetapi APK belum dibangun atau diuji pada emulator/perangkat di lingkungan ini. Lingkungan pembuatan saat ini tidak memiliki Android SDK (`android.jar`/`sdkmanager`) atau Gradle executable. Jangan menganggap ZIP ini sebagai APK siap instal.

## Fitur pada kode sumber
- Login demo Pemilik dan Kasir.
- Kasir: pilih menu, hitung transaksi, kurangi stok, dan tampilkan struk.
- Stok: harga jual, modal/unit, stok tersedia; Pemilik dapat mengubah dan menambah menu.
- Utang pelanggan: catat nominal/keterangan dan tandai lunas.
- Laporan: total penjualan, modal barang terjual, laba kotor, transaksi, dan utang belum lunas.
- Struk/laporan dapat dibagikan lewat menu Share Android.

## Login demo
- Pemilik: username `pemilik`, password `1234`
- Kasir: username `kasir`, password `1234`

**Ganti mekanisme login demo sebelum aplikasi dipakai untuk transaksi sungguhan.**

## Cara membangun APK dengan Android Studio
1. Di komputer, instal Android Studio versi stabil yang mendukung Android Gradle Plugin 8.7.3.
2. Pastikan Android SDK Platform 35 dan Android SDK Build-Tools terpasang melalui SDK Manager.
3. Ekstrak ZIP ini.
4. Android Studio → **Open** → pilih folder `warkop_loyal_celebes` (folder yang berisi `settings.gradle`).
5. Jika diminta, pilih JDK 17 atau versi JDK yang direkomendasikan Android Studio untuk Android Gradle Plugin 8.7.3.
6. Tunggu Gradle Sync. Jika diminta mengunduh komponen Android SDK/Gradle, izinkan.
7. Pilih **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
8. Jika build berhasil, Android Studio akan menampilkan notifikasi **Locate**. APK debug biasanya berada di `app/build/outputs/apk/debug/app-debug.apk`.
9. Salin APK ke HP Android dan instal. Izinkan instalasi dari sumber tersebut bila Android meminta.

## Checklist pengujian sebelum dipakai
- Login `pemilik`/`1234` dan `kasir`/`1234`; uji kombinasi salah.
- Pemilik menambah barang dan mengubah harga/modal/stok.
- Kasir menjual menu, cek stok berkurang dan total struk sesuai.
- Uji stok nol dan jumlah pesanan melebihi stok.
- Tambah utang pelanggan dan tandai lunas.
- Cocokkan total penjualan, modal barang, laba kotor, dan jumlah transaksi.
- Tutup lalu buka aplikasi lagi untuk memastikan data lokal tetap ada.
- Uji berbagi struk ke aplikasi/printer yang digunakan.

## Batasan dan catatan bisnis
- Data disimpan lokal di HP menggunakan SharedPreferences; belum ada sinkronisasi cloud atau backup otomatis.
- Login ini hanya demo: belum ada akun/password aman, pengelolaan sesi produksi, atau pembatasan akses yang kuat.
- Laporan saat ini menghitung **laba kotor** (penjualan dikurangi modal barang terjual), bukan laba bersih sesungguhnya. Biaya listrik, sewa, gaji, gas, bahan terbuang, dan biaya operasional lain belum dicatat.
- Utang pelanggan dicatat terpisah dan belum terhubung otomatis ke transaksi kredit.
- Struk memakai Android Share. Cetak langsung memerlukan integrasi SDK printer sesuai merek/model Bluetooth, USB, atau Wi-Fi.
- Proyek ini merupakan starter untuk diuji dan disempurnakan, bukan aplikasi produksi yang telah tersertifikasi atau diverifikasi.
