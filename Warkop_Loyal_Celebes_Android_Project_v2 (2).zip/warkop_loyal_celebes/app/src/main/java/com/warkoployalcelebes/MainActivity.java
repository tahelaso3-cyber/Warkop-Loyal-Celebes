package com.warkoployalcelebes;

import android.app.*;
import android.os.Bundle;
import android.graphics.Typeface;
import android.graphics.Color;
import android.content.*;
import android.view.*;
import android.widget.*;
import android.text.InputType;
import org.json.*;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    final int GREEN = Color.rgb(21,60,49), GOLD = Color.rgb(215,169,75), BG = Color.rgb(246,244,238);
    LinearLayout root, body, nav;
    android.content.SharedPreferences prefs;
    JSONArray products, sales, debts;
    String role = "", page = "Kasir";
    NumberFormat money = NumberFormat.getCurrencyInstance(new Locale("id","ID"));

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("warkop_data", MODE_PRIVATE);
        products = readArray("products", defaultProducts());
        sales = readArray("sales", new JSONArray());
        debts = readArray("debts", new JSONArray());
        if (prefs.getBoolean("logged", false)) { role = prefs.getString("role","Kasir"); showApp(); }
        else showLogin();
    }
    JSONArray defaultProducts() {
        JSONArray a = new JSONArray();
        addProduct(a,"Kopi Hitam",5000,2000,30);
        addProduct(a,"Kopi Susu",7000,3000,25);
        addProduct(a,"Es Teh",4000,1500,30);
        addProduct(a,"Indomie Goreng",10000,6500,20);
        addProduct(a,"Indomie Telur",13000,8000,15);
        addProduct(a,"Pisang Goreng",8000,4000,15);
        return a;
    }
    void addProduct(JSONArray a,String name,double price,double cost,int stock) {
        JSONObject o = new JSONObject();
        try { o.put("id",System.currentTimeMillis()+a.length()); o.put("name",name); o.put("price",price); o.put("cost",cost); o.put("stock",stock); a.put(o); } catch(Exception ignored){}
    }
    JSONArray readArray(String k, JSONArray def) {
        String s = prefs.getString(k,null);
        if(s==null) return def;
        try { return new JSONArray(s); } catch(Exception e) { return def; }
    }
    void save() {
        prefs.edit().putString("products",products.toString()).putString("sales",sales.toString()).putString("debts",debts.toString()).apply();
    }
    String rp(double n) { return money.format(n).replace(",00",""); }
    JSONObject obj(JSONArray a,int i) { return a.optJSONObject(i); }
    LinearLayout column() {
        LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l;
    }
    TextView text(String s,int size,int color,boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        t.setPadding(0,6,0,6); if(bold)t.setTypeface(null,Typeface.BOLD); return t;
    }
    Button button(String s) {
        Button b = new Button(this); b.setText(s); b.setAllCaps(false); b.setTextColor(Color.WHITE);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(GREEN)); return b;
    }
    EditText edit(String hint, boolean numeric) {
        EditText e = new EditText(this); e.setHint(hint); e.setSingleLine(true);
        if(numeric)e.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);
        e.setPadding(18,4,18,4); return e;
    }
    void shell(String title) {
        root = column(); root.setBackgroundColor(BG);
        LinearLayout header = column(); header.setPadding(20,18,20,14); header.setBackgroundColor(GREEN);
        header.addView(text("☕ WARKOP LOYAL CELEBES",20,Color.WHITE,true));
        header.addView(text(title+" • Login: "+role,13,Color.rgb(225,230,220),false));
        root.addView(header);
        ScrollView scroll = new ScrollView(this); body=column(); body.setPadding(16,12,16,16); scroll.addView(body);
        root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        nav = new LinearLayout(this); nav.setPadding(4,4,4,4); nav.setBackgroundColor(Color.WHITE);
        String[] pages={"Kasir","Stok","Utang","Laporan"};
        for(String p:pages) { Button b=button(p); b.setTextSize(12); b.setPadding(2,4,2,4); b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(p.equals(page)?GOLD:GREEN)); b.setTextColor(p.equals(page)?GREEN:Color.WHITE);
            b.setOnClickListener(v->{page=p; renderPage();}); nav.addView(b,new LinearLayout.LayoutParams(0,52,1)); }
        root.addView(nav); setContentView(root);
    }
    void showLogin() {
        root=column(); root.setBackgroundColor(GREEN);
        LinearLayout card=column(); card.setPadding(28,36,28,28); card.setGravity(Gravity.CENTER_VERTICAL);
        card.addView(text("☕",54,GOLD,true)); card.addView(text("WARKOP LOYAL CELEBES",25,Color.WHITE,true));
        card.addView(text("Kasir • Stok • Utang • Laporan",15,Color.WHITE,false));
        EditText user=edit("Username",false), pass=edit("Password",false); pass.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);
        card.addView(user); card.addView(pass);
        Spinner roles=new Spinner(this); roles.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"Pemilik","Kasir"})); card.addView(roles);
        Button login=button("Masuk"); card.addView(login);
        card.addView(text("Demo awal: pemilik / 1234  •  kasir / 1234",13,Color.LTGRAY,false));
        login.setOnClickListener(v->{
            String u=user.getText().toString().trim(), p=pass.getText().toString();
            String r=roles.getSelectedItem().toString();
            boolean ok = p.equals("1234") && ((r.equals("Pemilik")&&u.equals("pemilik"))||(r.equals("Kasir")&&u.equals("kasir")));
            if(ok) { role=r; prefs.edit().putBoolean("logged",true).putString("role",role).apply(); showApp(); }
            else new AlertDialog.Builder(this).setMessage("Login tidak cocok. Periksa username, password, dan peran.").setPositiveButton("OK",null).show();
        });
        root.addView(card,new LinearLayout.LayoutParams(-1,-1)); setContentView(root);
    }
    void showApp() { page="Kasir"; renderPage(); }
    void renderPage() {
        shell(page);
        if(page.equals("Kasir")) renderCashier();
        else if(page.equals("Stok")) renderStock();
        else if(page.equals("Utang")) renderDebts();
        else renderReport();
        if(role.equals("Pemilik")) {
            Button logout=button("Keluar akun"); logout.setOnClickListener(v->{prefs.edit().putBoolean("logged",false).apply(); showLogin();});
            body.addView(logout);
        }
    }
    void renderCashier() {
        body.addView(text("Pilih menu untuk menambahkan ke pesanan",18,GREEN,true));
        EditText customer=edit("Nama pelanggan (opsional)",false); body.addView(customer);
        for(int i=0;i<products.length();i++) {
            JSONObject p=obj(products,i); if(p==null)continue;
            String name=p.optString("name"); int stock=p.optInt("stock");
            LinearLayout row=new LinearLayout(this); row.setGravity(Gravity.CENTER_VERTICAL);
            LinearLayout labels=column(); labels.addView(text(name,16,Color.DKGRAY,true));
            labels.addView(text(rp(p.optDouble("price"))+" • stok "+stock,13,Color.GRAY,false));
            row.addView(labels,new LinearLayout.LayoutParams(0,-2,1));
            Button add=button("+"); add.setEnabled(stock>0); add.setOnClickListener(v->checkoutDialog(p,customer.getText().toString())); row.addView(add);
            body.addView(row); divider(body);
        }
        Button logout=button("Keluar / Ganti akun"); logout.setOnClickListener(v->{prefs.edit().putBoolean("logged",false).apply();showLogin();}); body.addView(logout);
    }
    void checkoutDialog(JSONObject p,String customer) {
        EditText qty=edit("Jumlah",true); qty.setText("1");
        EditText note=edit("Catatan pesanan (opsional)",false);
        LinearLayout box=column(); box.setPadding(16,4,16,4); box.addView(text(p.optString("name")+" • "+rp(p.optDouble("price")),16,GREEN,true)); box.addView(qty); box.addView(note);
        new AlertDialog.Builder(this).setTitle("Tambah pesanan").setView(box).setNegativeButton("Batal",null).setPositiveButton("Bayar", (d,w)->{
            int q; try{q=Integer.parseInt(qty.getText().toString());}catch(Exception e){q=0;}
            int stock=p.optInt("stock"); if(q<=0||q>stock){toast("Jumlah tidak valid atau stok tidak cukup");return;}
            p.remove("stock"); try{p.put("stock",stock-q);}catch(Exception ignored){}
            double total=q*p.optDouble("price");
            JSONObject sale=new JSONObject();
            try{sale.put("id",System.currentTimeMillis());sale.put("customer",customer.trim().isEmpty()?"Pelanggan":customer.trim());sale.put("product",p.optString("name"));sale.put("qty",q);sale.put("total",total);sale.put("cost",q*p.optDouble("cost"));sale.put("time",new SimpleDateFormat("dd/MM HH:mm",Locale.getDefault()).format(new Date()));sale.put("note",note.getText().toString());sale.put("cashier",role);sales.put(sale);}catch(Exception ignored){}
            save(); receipt(sale); renderPage();
        }).show();
    }
    void receipt(JSONObject s) {
        String receipt="WARKOP LOYAL CELEBES\n-----------------------------\n"+s.optString("time")+"\nPelanggan: "+s.optString("customer")+"\nKasir: "+s.optString("cashier")+"\n"+s.optString("product")+" x"+s.optInt("qty")+"\nTOTAL: "+rp(s.optDouble("total"))+"\n"+s.optString("note")+"\n-----------------------------\nTerima kasih!";
        new AlertDialog.Builder(this).setTitle("Transaksi berhasil").setMessage(receipt).setPositiveButton("Selesai",null).setNeutralButton("Bagikan / Cetak",(d,w)->{
            Intent i=new Intent(Intent.ACTION_SEND);i.setType("text/plain");i.putExtra(Intent.EXTRA_TEXT,receipt);
            startActivity(Intent.createChooser(i,"Kirim struk ke printer / aplikasi"));
        }).show();
    }
    void renderStock() {
        body.addView(text("Manajemen stok dan harga pokok",18,GREEN,true));
        if(!role.equals("Pemilik")) body.addView(text("Kasir dapat melihat stok. Penambahan/edit stok hanya untuk pemilik.",13,Color.GRAY,false));
        for(int i=0;i<products.length();i++) {
            JSONObject p=obj(products,i); if(p==null)continue;
            body.addView(text(p.optString("name")+" — stok "+p.optInt("stock"),16,Color.DKGRAY,true));
            body.addView(text("Harga jual "+rp(p.optDouble("price"))+" • Modal/unit "+rp(p.optDouble("cost")),13,Color.GRAY,false));
            if(role.equals("Pemilik")) {
                Button edit=button("Ubah harga, modal & stok");
                edit.setOnClickListener(v->editProduct(p)); body.addView(edit);
            }
            divider(body);
        }
        if(role.equals("Pemilik")) { Button add=button("+ Tambah barang"); add.setOnClickListener(v->addProductDialog()); body.addView(add); }
    }
    void editProduct(JSONObject p) {
        LinearLayout box=column(); EditText price=edit("Harga jual",true), cost=edit("Modal per unit",true), stock=edit("Jumlah stok",true);
        price.setText(""+(int)p.optDouble("price"));cost.setText(""+(int)p.optDouble("cost"));stock.setText(""+p.optInt("stock"));
        box.addView(price);box.addView(cost);box.addView(stock);
        new AlertDialog.Builder(this).setTitle(p.optString("name")).setView(box).setNegativeButton("Batal",null).setPositiveButton("Simpan",(d,w)->{
            try{p.put("price",Double.parseDouble(price.getText().toString()));p.put("cost",Double.parseDouble(cost.getText().toString()));p.put("stock",Integer.parseInt(stock.getText().toString()));save();renderPage();}catch(Exception e){toast("Data harga/stok tidak valid");}
        }).show();
    }
    void addProductDialog() {
        LinearLayout box=column(); EditText name=edit("Nama barang/menu",false), price=edit("Harga jual",true),cost=edit("Modal per unit",true),stock=edit("Stok awal",true);
        box.addView(name);box.addView(price);box.addView(cost);box.addView(stock);
        new AlertDialog.Builder(this).setTitle("Tambah barang").setView(box).setNegativeButton("Batal",null).setPositiveButton("Simpan",(d,w)->{
            try{if(name.getText().toString().trim().isEmpty())throw new Exception();JSONObject p=new JSONObject();p.put("id",System.currentTimeMillis());p.put("name",name.getText().toString().trim());p.put("price",Double.parseDouble(price.getText().toString()));p.put("cost",Double.parseDouble(cost.getText().toString()));p.put("stock",Integer.parseInt(stock.getText().toString()));products.put(p);save();renderPage();}catch(Exception e){toast("Lengkapi data dengan benar");}
        }).show();
    }
    void renderDebts() {
        body.addView(text("Catat utang pelanggan",18,GREEN,true));
        EditText name=edit("Nama pelanggan",false), amount=edit("Nominal utang",true), note=edit("Keterangan",false);
        body.addView(name);body.addView(amount);body.addView(note);
        Button add=button("Simpan utang"); add.setOnClickListener(v->{
            try{if(name.getText().toString().trim().isEmpty())throw new Exception();JSONObject d=new JSONObject();d.put("name",name.getText().toString().trim());d.put("amount",Double.parseDouble(amount.getText().toString()));d.put("note",note.getText().toString());d.put("paid",false);d.put("time",new SimpleDateFormat("dd/MM/yyyy",Locale.getDefault()).format(new Date()));debts.put(d);save();renderPage();}catch(Exception e){toast("Isi nama dan nominal utang");}
        }); body.addView(add); divider(body);
        for(int i=0;i<debts.length();i++){JSONObject d=obj(debts,i);if(d==null)continue;
            body.addView(text(d.optString("name")+" — "+rp(d.optDouble("amount")),16,Color.DKGRAY,true));
            body.addView(text(d.optString("note")+" • "+d.optString("time"),13,Color.GRAY,false));
            if(!d.optBoolean("paid")) {Button paid=button("Tandai lunas");paid.setOnClickListener(v->{try{d.put("paid",true);save();renderPage();}catch(Exception ignored){}});body.addView(paid);}
            else body.addView(text("LUNAS",13,GREEN,true));
            divider(body);
        }
    }
    void renderReport() {
        double revenue=0,cost=0;int count=sales.length();
        for(int i=0;i<sales.length();i++){JSONObject s=obj(sales,i);if(s!=null){revenue+=s.optDouble("total");cost+=s.optDouble("cost");}}
        double outstanding=0;for(int i=0;i<debts.length();i++){JSONObject d=obj(debts,i);if(d!=null&&!d.optBoolean("paid"))outstanding+=d.optDouble("amount");}
        body.addView(text("Ringkasan penjualan",18,GREEN,true));
        stat("Total penjualan",rp(revenue));stat("Estimasi modal barang terjual",rp(cost));stat("Laba kotor (belum biaya operasional)",rp(revenue-cost));stat("Transaksi tercatat",""+count);stat("Utang belum lunas",rp(outstanding));
        body.addView(text("Riwayat transaksi",18,GREEN,true));
        for(int i=sales.length()-1;i>=0;i--){JSONObject s=obj(sales,i);if(s==null)continue;body.addView(text(s.optString("time")+" • "+s.optString("product")+" x"+s.optInt("qty"),15,Color.DKGRAY,true));body.addView(text(s.optString("customer")+" — "+rp(s.optDouble("total")),13,Color.GRAY,false));divider(body);}
        body.addView(text("Catatan: laba bersih belum dikurangi listrik, sewa, gaji, gas, dan biaya operasional lain. Masukkan biaya tersebut dalam pembukuan terpisah.",13,Color.GRAY,false));
        Button export=button("Bagikan laporan");export.setOnClickListener(v->{String report="LAPORAN WARKOP LOYAL CELEBES\nPenjualan: "+rp(revenue)+"\nModal barang: "+rp(cost)+"\nLaba kotor: "+rp(revenue-cost)+"\nUtang belum lunas: "+rp(outstanding)+"\nTransaksi: "+count;Intent in=new Intent(Intent.ACTION_SEND);in.setType("text/plain");in.putExtra(Intent.EXTRA_TEXT,report);startActivity(Intent.createChooser(in,"Bagikan laporan"));});body.addView(export);
    }
    void stat(String label,String value){LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);TextView a=text(label,14,Color.DKGRAY,false),b=text(value,15,GREEN,true);row.addView(a,new LinearLayout.LayoutParams(0,-2,1));row.addView(b);body.addView(row);divider(body);}
    void divider(LinearLayout l){View v=new View(this);v.setBackgroundColor(Color.rgb(220,218,208));l.addView(v,new LinearLayout.LayoutParams(-1,1));}
    void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
}
